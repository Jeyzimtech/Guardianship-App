# Edu Connect store graphics

Upload these files in Google Play Console under Main store listing / Graphics:

- App icon: `app-icon-512.png` (512 x 512).
- Feature graphic: `feature-graphic-1024x500.png` (1024 x 500).
- Phone screenshots: the four numbered images in `phone-screenshots/` (1080 x 1920), in order.

The `raw/` directory contains the corresponding unframed app captures if plain screenshots are preferred. Do not upload both sets as duplicates.

These are actual Flutter widget renders using the application's screen code and fictional fixture data. They are not photographs or captures from a connected physical Android device. The promotional images preserve the captured interface and add external headings and framing. No production account or learner data is included.

The icon preserves the existing app logo. All upload images are PNG RGB without transparency. The icon is below the 1024 KB limit. No health-related promotional content is included. The application code, existing app links, and AAB were not changed.

`asset-preview.png` is a review contact sheet, not a store upload asset.

Official requirements: https://support.google.com/googleplay/android-developer/answer/9866151
